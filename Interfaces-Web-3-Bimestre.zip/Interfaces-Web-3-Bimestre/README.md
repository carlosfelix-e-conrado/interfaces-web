# Interfaces Web - 3º Bimestre

Alunos:
- Carlos Eduardo Félix
- Conrado Gazano

Conteúdos reunidos:
1. Casa do Fio
2. Computação em Nuvem

## Como abrir
Entre na pasta do projeto desejado e abra o arquivo `index.html` no navegador.

## Estrutura
- `casa-do-fio/` - site de costura e brechó com várias páginas.
- `computacao-em-nuvem/` - site explicativo sobre computação em nuvem, com página Sobre e quiz.
