# Casa do Fio

Projeto de Interfaces Web do 3º bimestre.

## Tecnologias
- HTML5
- CSS3
- Bootstrap 5.3.3
- JavaScript

## Páginas
- index.html
- costura.html
- brecho.html
- sapatos.html
- ternos.html
- camisas.html
- saltos.html
- bolsas.html
- contato.html

Slogan: **Costurando estilo, renovando histórias.**
