# Computação em Nuvem

Projeto de Interfaces Web do 3º bimestre.

## Arquivos
- `index.html`
- `sobre.html`
- `style.css`
- `script.js`

## Conteúdo
- Conceito de computação em nuvem
- Nuvem pública, privada e híbrida
- IaaS, PaaS e SaaS
- Vantagens da nuvem
- Quiz em JavaScript
- Página Sobre

## Alunos
Carlos Eduardo Félix e Conrado Gazano — 1º D
