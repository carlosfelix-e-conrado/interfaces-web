function responder(opcao) {
  const resultado = document.getElementById("resultado");
  if (opcao === "SaaS") {
    resultado.innerHTML = '<div class="alert alert-success mb-0">Correto! SaaS significa Software como Serviço.</div>';
  } else {
    resultado.innerHTML = '<div class="alert alert-danger mb-0">Tente novamente.</div>';
  }
}
